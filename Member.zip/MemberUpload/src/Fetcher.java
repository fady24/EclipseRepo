import org.apache.poi.util.SystemOutLogger;

public class Fetcher {
	
	
	
	public Fetcher()
	{
		
	}
	
	
	public static String getNextChdrnum(){
		try{
			
			//System.out.print("");
			
			
			
		}catch(Exception e){
			return "fail";
		}
		
		
		return null;
		
	}

}
